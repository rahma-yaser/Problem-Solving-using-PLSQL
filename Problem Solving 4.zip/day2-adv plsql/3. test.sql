-- 3. Create a package specification and body called DEPT_PKG, be creating ADD_DEPT ( 4 params ) , UPD_DEPT ( 4 params ), and DEL_DEPT(1 param) procedures as well as your GET_DEPT function( 1 param ) return dept_name only
--Test procedure
select * from departments;
declare


begin

                dept_pkg.add_dept(280, 'Data Science',101,1700);
                dept_pkg.upd_dept(280, 'Data Analysis',101,1700);
                dept_pkg.del_dept(280);

end;
select * from departments;

--Test funciton
declare

        v_result varchar2(40);

begin

                v_result := dept_pkg.get_dept(600);
                dbms_output.put_line('the deparment name is >>>> ' || v_result);

end;
