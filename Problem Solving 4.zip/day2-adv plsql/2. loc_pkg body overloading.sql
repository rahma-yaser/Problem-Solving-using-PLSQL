create or replace package body loc_pkg2
is

        --ADD_LOC procedure
        procedure ADD_LOC(v_location_id number, v_street_address varchar2, v_postal_code varchar2, v_city varchar2, v_state_province varchar2, v_country_id char)
        is

        invalid_country_ids exception;
        pragma exception_init(invalid_country_ids, -02291);  

        begin

                insert into locations (LOCATION_ID    , STREET_ADDRESS, POSTAL_CODE    , CITY, STATE_PROVINCE, COUNTRY_ID)
                values (v_location_id, v_street_address, v_postal_code,  v_city, v_state_province, v_country_id);
                
                exception
                when invalid_country_ids THEN
                dbms_output.put_line('Invalid COUNTRY_ID -> try it upper case like for Egypt : EG etc.');
                
        end;
              
        
        --ADD_LOC procedure overloading
        procedure ADD_LOC(v_city varchar2)
        is

        begin
                
                insert into locations (LOCATION_ID , CITY)
                values (locations_seq.nextval, v_city);
                 
        end;
        
        
        --Query_LOC function
        function Query_loc(v_location_id number)
        return varchar2
        is
                v_region_name varchar2(25); 
                v_country_name varchar2(40);
                v_location number(4);
                v_street_address varchar2(40);
                v_postal_code varchar2(12);
                v_city varchar2(30);
                total_data varchar2(500);

        begin

                select r.region_name, c.country_name, l.location_id, l.street_address, l.postal_code, l.city
                into v_region_name, v_country_name, v_location, v_street_address, v_postal_code, v_city
                from regions r join countries c
                on r.region_id = c.region_id
                join locations l
                on c.country_id = l.country_id
                where l.location_id = v_location_id;
                
                
                total_data := v_region_name || ', ' || v_country_name || ', ' ||v_location || ', ' ||v_street_address || ', ' ||v_postal_code || ', ' || v_city;
                return total_data;
                
        end;
        
        
        --GET_LOC function
        function GET_LOC(v_city out varchar2, v_location_id in number)
        return varchar2
        is

                v_street_address varchar2(40);

        begin

                select street_address, city
                into v_street_address, v_city
                from locations
                where location_id = v_location_id;
                
                return v_street_address;

        end;


end;
show errors;