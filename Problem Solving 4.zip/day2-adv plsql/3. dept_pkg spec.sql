create or replace package dept_pkg
is
        
        -- ADD_DEPT procedure
        procedure add_dept(v_DEPARTMENT_ID number, v_DEPARTMENT_NAME varchar2, v_MANAGER_ID number, v_LOCATION_ID number);
        
        --UPD procedure
        procedure upd_dept(v_DEPARTMENT_ID number, v_DEPARTMENT_NAME varchar2, v_MANAGER_ID number, v_LOCATION_ID number);
        
        --DEL_DEPT procedure
        procedure del_dept(v_DEPARTMENT_ID number);
        
        --GET_DEPT function
        function get_dept(v_department_id number)
        return varchar2;

end;
show errors;