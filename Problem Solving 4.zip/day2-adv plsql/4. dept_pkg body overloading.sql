create or replace package body dept_pkg2
is

        -- ADD_DEPT procedure
        procedure add_dept(v_DEPARTMENT_ID number, v_DEPARTMENT_NAME varchar2, v_MANAGER_ID number, v_LOCATION_ID number) 
        is
                
                v_dummy number;

        begin

                select 1 
                into v_dummy
                from employees
                where employee_id = v_MANAGER_ID;
                
                select 1
                into v_dummy
                from locations
                where location_id = v_LOCATION_ID;
                
                insert into departments(DEPARTMENT_ID, DEPARTMENT_NAME, MANAGER_ID, LOCATION_ID)
                values(v_DEPARTMENT_ID, v_DEPARTMENT_NAME, v_MANAGER_ID, v_LOCATION_ID);
                
                dbms_output.put_line('department inserted successfully <3');
                
                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                DBMS_OUTPUT.PUT_LINE('Error: Manager ID or Location ID does not exist.');

        end;        

        --UPD_DEPT procedure
        procedure upd_dept(v_DEPARTMENT_ID number, v_DEPARTMENT_NAME varchar2, v_MANAGER_ID number, v_LOCATION_ID number) 
        is
                
                v_dummy number;

        begin

                select 1 
                into v_dummy
                from employees
                where employee_id = v_MANAGER_ID;
                
                select 1
                into v_dummy
                from locations
                where location_id = v_LOCATION_ID;
                
                update departments
                set DEPARTMENT_NAME = v_DEPARTMENT_NAME, MANAGER_ID = v_MANAGER_ID, LOCATION_ID = v_LOCATION_ID
                where department_id = v_DEPARTMENT_ID;
                
                dbms_output.put_line('department updated successfully <3');
                
                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                DBMS_OUTPUT.PUT_LINE('Error: Manager ID or Location ID does not exist.');

        end;
        
        --DEL_DEPT procedure
        procedure del_dept(v_DEPARTMENT_ID number) 
        is
                
        begin

                delete from departments
                where department_id = v_DEPARTMENT_ID;
                
                dbms_output.put_line('department deleted successfully <3');
                

        end;
        
        --GET_DEPT function
        function get_dept(v_department_id number)
        return varchar2
        is

                v_dept_name varchar2(40);
                
        begin

                select department_name
                into v_dept_name
                from departments
                where department_id = v_department_id;
                
                return v_dept_name;
        end;
        
        --GET_DEPT function overloading
        function get_dept(v_department_name varchar2)
        return departments%rowtype
        is

                v_dept_record departments%rowtype;
                
        begin

                select *
                into v_dept_record
                from departments
                where department_name = v_department_name;
                
                return v_dept_record;
        end;

        
end;
show errors;