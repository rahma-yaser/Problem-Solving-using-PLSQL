--4. Modify DEPT_PKG by adding GET_DEPT function overloading that accepts DEPT_name, and return %departments row type.
--Test procedure
select * from departments;
declare


begin

                dept_pkg2.add_dept(280, 'Data Science',101,1700);
                dept_pkg2.upd_dept(280, 'Data Analysis',101,1700);
                dept_pkg2.del_dept(280);

end;
select * from departments;

--Test funciton
set serveroutput on
declare

        v_dept_name varchar2(40);
        
begin

                v_dept_name := dept_pkg2.get_dept(600);
                dbms_output.put_line('the deparment name is >>>> ' || v_dept_name);
               
end;

declare

        v_dept_record departments%rowtype;
        
begin

                
                v_dept_record := dept_pkg2.get_dept('CS');
                dbms_output.put_line('the deparment total record is >>>> ' || v_dept_record.department_id ||' ' || v_dept_record.department_name||' '||v_dept_record.manager_id||' '||v_dept_record.location_id|| ' <3');

end;
