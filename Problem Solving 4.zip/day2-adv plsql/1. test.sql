--1. Create a package specification and body called LOC_PKG, containing a copy of your ADD_LOC procedure and Query_LOC, function as well as your GET_LOC function.
--test procedure
select * from locations;
declare
      
begin
        
        loc_pkg.ADD_LOC(3800, 'Assiut University', '71515', 'Assiut', 'Egypt', 'EG');
        

end;
select * from locations;


--test funciton
declare

        return_result varchar2(500);
        street varchar2(40);
        city varchar2(25);

begin
        
        return_result := loc_pkg.Query_loc(2000);
        dbms_output.put_line(return_result);
        
        street := loc_pkg.GET_LOC(city, 1000);
        dbms_output.put_line(street || ' , ' || city);

end;
