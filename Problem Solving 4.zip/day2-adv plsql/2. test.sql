--2. Copy and modify the code for the LOC_PKG package that you created and overload the ADD_LOC procedure.  As you can insert only city only, and use sequence to insert location_id.
--test procedure
select * from locations;
declare
      
begin
        
        loc_pkg2.ADD_LOC(3900, 'Assiut University', '71515', 'Assiut', 'Egypt', 'EG');

        

end;
select * from locations;

select * from locations;
declare
      
begin
        
        loc_pkg2.ADD_LOC('Monaco');

        

end;
select * from locations;

--test funciton
declare

        return_result varchar2(500);
        street varchar2(40);
        city varchar2(25);

begin
        
        return_result := loc_pkg2.Query_loc(2000);
        dbms_output.put_line(return_result);
        
        street := loc_pkg2.GET_LOC(city, 1000);
        dbms_output.put_line(street || ' , ' || city);

end;
