create or replace package loc_pkg2
is

        --ADD_LOC procedure
        procedure ADD_LOC (v_location_id number, v_street_address varchar2, v_postal_code varchar2, v_city varchar2, v_state_province varchar2, v_country_id char);
        
         --ADD_LOC procedure overloading
        procedure ADD_LOC (v_city varchar2);
        
        --Query_LOC function
        function Query_loc(v_location_id number)
        return varchar2;
        
        --GET_LOC function
        function GET_LOC(v_city out varchar2, v_location_id in number)
        return varchar2;

end;
show errors;